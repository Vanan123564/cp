import requests
import sys

victim = sys.argv[1]
method = sys.argv[2]
checkhost = sys.argv[3]
proof_image_link = sys.argv[4]
webhook = sys.argv[5]

data = {
    "username" : 'Power Proof Uploader SKID-XV'
}

data["embeds"] = [
    {
        "description" : f"`Target:`\n[ {victim} ]\n`Method :`\n[ {method} ]\n`Check-Host Url:`\n[ {checkhost} ]",
        "title" : "Power Proof Uploader",
        "image" : {
          "url" : f"{proof_image_link}"
        }
    }
]

result = requests.post(webhook, json = data)

try:
    result.raise_for_status()
except requests.exceptions.HTTPError as err:
    print(err)
else:
    print("Power Proof UPLOADER sending by SKID-XV!, Code {}".format(result.status_code))